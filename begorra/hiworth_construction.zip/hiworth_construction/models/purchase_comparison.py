from openerp import models, fields, api

class PurchaseComparison(models.Model):
    _name = 'purchase.comparison'
    _rec_name = 'number'

    @api.one
    def button_request(self):
        self.state = 'requested'

    @api.one
    def button_approve1(self):
        self.user_id1 = self.env.user.id
        self.state = 'validated1'


    @api.one
    def button_approve2(self):
        self.user_id2 = self.env.user.id
        l =[self.total_amt3,self.total_amt2,self.total_amt1]
        if min(l) == self.total_amt1:
            self.partner_selected = self.partner_id1.id
        if min(l) == self.total_amt2:
            self.partner_selected = self.partner_id2.id
        if min(l) == self.total_amt3:
            self.partner_selected = self.partner_id3.id
        self.state = 'validated2'

    @api.one
    def button_po_create(self):
        list = []
        flag = 0
        uom = self.env['product.uom'].search([('name', '=', 'Service')])
        if not uom:
            category_id = self.env['product.uom.categ'].search([('name', '=', 'Unit')])
            uom = self.env['product.uom'].create({
                'name': 'Service',
                'category_id': category_id.id
            })
        loading = self.env['product.product'].search([('name', '=', 'LOADING CHARGE')])
        if not loading:
            loading = self.env['product.product'].create({
                'name': 'LOADING CHARGE',
                'uom_id': uom.id
            })
        transport = self.env['product.product'].search([('name', '=', 'TRANSPORTING CHARGE')])
        if not transport:
            transport = self.env['product.product'].create({
                'name': 'TRANSPORTING CHARGE',
                'uom_id': uom.id
            })
        vals = {
            'partner_id': self.partner_selected.id,
            'pricelist_id': self.partner_selected.property_product_pricelist_purchase.id,
            'minimum_planned_date': self.date,
            'project_id': self.project_id.id,
            'location_id': self.project_id.location_id.id,
            'account_id': self.partner_selected.property_account_payable.id,
            'mpr_id':self.mpr_id.id
        }
        if self.partner_selected.id == self.partner_id1.id:
            flag = 1
            if self.loading_charge1:
                list.append((0, 0, {
                    'product_id': loading.id,
                    'name': loading.name,
                    'required_qty': 1,
                    'product_uom': uom.id,
                    'expected_rate': self.loading_charge1,
                    'price_unit': 0.0,
                    'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
                }))
            if self.transport_cost1:
                list.append((0, 0, {
                    'product_id': transport.id,
                    'name': transport.name,
                    'required_qty': 1,
                    'product_uom': uom.id,
                    'expected_rate': self.transport_cost1,
                    'price_unit': 0.0,
                    'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
                }))
        if self.partner_selected.id == self.partner_id2.id:
            flag = 2
            if self.loading_charge2:
                list.append((0, 0, {
                    'product_id': loading.id,
                    'name': loading.name,
                    'required_qty': 1,
                    'product_uom': uom.id,
                    'expected_rate': self.loading_charge2,
                    'price_unit': 0.0,
                    'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
                }))
            if self.transport_cost2:
               list.append((0, 0, {
                   'product_id': transport.id,
                   'name': transport.name,
                   'required_qty': 1,
                   'product_qty': 1,
                   'product_uom': uom.id,
                   'expected_rate': self.transport_cost2,
                   'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
               }))
        if self.partner_selected.id == self.partner_id3.id:
            flag = 3
            if self.loading_charge3:
                list.append((0, 0, {
                    'product_id': loading.id,
                    'name': loading.name,
                    'required_qty': 1,
                    'product_qty': 1,
                    'product_uom': uom.id,
                    'expected_rate': self.loading_charge3,
                    'price_unit': 0.0,
                    'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
                }))
            if self.transport_cost3:
                list.append((0, 0, {
                    'product_id': transport.id,
                    'name': transport.name,
                    'required_qty': 1,
                    'product_uom': uom.id,
                    'expected_rate': self.transport_cost3,
                    'price_unit': 0.0,
                    'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
                }))
        for l in self.comparison_line:
            dictionary = {
                'product_id': l.product_id.id,
                'name': l.product_id.name,
                'required_qty': l.qty,
                'product_uom': l.product_id.uom_id.id,
                'price_unit': 0.0,
                'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
            }
            if flag == 1:
                vals['payment_term_id'] = self.payment_term1.id
                vals['notes'] = str(self.remark) + " " +str(self.remark1) or ''
                dictionary['expected_rate'] = l.rate1
                if self.tax_id1.id:
                    dictionary['taxes_id'] = [(4, self.tax_id1.id)]
                dictionary['price_unit'] = 0

            if flag == 2:
                vals['payment_term_id'] = self.payment_term2.id
                vals['notes'] = str(self.remark) + " " +str(self.remark2) or ''
                dictionary['expected_rate'] = l.rate2
                if self.tax_id2.id:
                    dictionary['taxes_id'] = [(4, self.tax_id2.id)]
                dictionary['price_unit'] = 0

            if flag == 3:
                vals['payment_term_id'] = self.payment_term3.id
                vals['notes'] = str(self.remark) + " " +str(self.remark3) or ''
                dictionary['expected_rate'] = l.rate3
                if self.tax_id3.id:
                    dictionary['taxes_id'] = [(4, self.tax_id3.id)]
                dictionary['price_unit'] = 0
            list.append((0,0, dictionary))
        vals['order_line'] = list
        purchase_id = self.env['purchase.order'].create(vals)
        self.purchase_id = purchase_id.id
        self.state = 'po'
        self.mpr_id.state = 'purchase'

    @api.multi
    def button_view_purchase(self):
        res = {
            'type': 'ir.actions.act_window',
            'name': 'Purchases',
            'res_model': 'purchase.order',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'target': 'current',
            'domain': [('id', '=', self.purchase_id.id)]
        }

        return res


    @api.one
    def get_total(self):
        for s in self:
            t1 = 0.0
            t2 = 0.0
            t3 = 0.0
            for l in s.comparison_line:
                t1 += l.sub_total1
                t2 += l.sub_total2
                t3 += l.sub_total3
            if s.tax_id1 and s.tax_id2 and s.tax_id3:
                if not s.tax_id1.price_include:
                    t1 = t1 + t1 * s.tax_id1.amount
                if not s.tax_id2.price_include:
                    t2 = t2 + t2 * s.tax_id2.amount
                if not s.tax_id3.price_include:
                    t3 = t3 + t3 * s.tax_id3.amount
            s.total_amt1 = t1 + s.loading_charge1 + s.transport_cost1
            s.total_amt2 = t2 + s.loading_charge2 + s.transport_cost2
            s.total_amt3 = t3 + s.loading_charge3 + s.transport_cost3

    project_id = fields.Many2one('project.project', 'Project')
    number = fields.Char('Purchase Comparison Number:')
    mpr_id = fields.Many2one('site.purchase',string="Material Requistion")
    date = fields.Date('Indent Date')
    partner_id1 = fields.Many2one('res.partner', 'Supplier')
    remark1 = fields.Char('Remark')
    partner_id2 = fields.Many2one('res.partner', 'Supplier')
    remark2 = fields.Char('Remark')
    partner_id3 = fields.Many2one('res.partner', 'Supplier')
    remark3 = fields.Char('Remark')
    state = fields.Selection([('draft', 'Draft'), ('requested', 'Requested'), ('validated1', 'First Approval'), ('validated2', 'Approved'), ('po', 'Purchase Order')],default='draft')
    comparison_line = fields.One2many('purchase.comparison.line', 'res_id', 'Comparison Line')
    purchase_id = fields.Many2one('purchase.order', 'Purchase Order')

    tax_id1 = fields.Many2one('account.tax', 'GST')
    tax_id2 = fields.Many2one('account.tax', 'GST')
    tax_id3 = fields.Many2one('account.tax', 'GST')

    p_n_f1 =fields.Char('P&F')
    p_n_f2 =fields.Char('P&F')
    p_n_f3 =fields.Char('P&F')

    loading_charge1 = fields.Float('Loading Charge')
    loading_charge2 = fields.Float('Loading Charge')
    loading_charge3 = fields.Float('Loading Charge')

    transport_cost1 = fields.Float('Transport Cost')
    transport_cost2 = fields.Float('Transport Cost')
    transport_cost3 = fields.Float('Transport Cost')

    delivery_period1 = fields.Char('Ready To Stock')
    delivery_period2 = fields.Char('Ready To Stock')
    delivery_period3 = fields.Char('Ready To Stock')

    payment_term1 = fields.Many2one('account.payment.term', 'Term Of Payment')
    payment_term2 = fields.Many2one('account.payment.term', 'Term Of Payment')
    payment_term3 = fields.Many2one('account.payment.term', 'Term Of Payment')

    total_amt3 = fields.Float('Total Amount', compute='get_total')
    total_amt2 = fields.Float('Total Amount', compute='get_total')
    total_amt1 = fields.Float('Total Amount', compute='get_total')

    partner_selected = fields.Many2one('res.partner', 'Vendor Selected')
    remark = fields.Text('Note')
    user_id1 = fields.Many2one('res.users', 'Approved By')
    user_id2 = fields.Many2one('res.users', 'Approved By')

class PurchaseComparisonLine(models.Model):

    _name = 'purchase.comparison.line'

    @api.onchange('product_id')
    def onchange_product(self):
        self.uom = self.product_id.uom_id.id

    @api.one
    def get_total(self):
        for s in self:
            s.sub_total1 = s.rate1 * s.qty
            s.sub_total2 = s.rate2 * s.qty
            s.sub_total3 = s.rate3 * s.qty

    res_id = fields.Many2one('purchase.comparison', 'Purchase Comparison')
    product_id = fields.Many2one('product.product', 'Description')
    qty = fields.Float('Quantity')
    uom = fields.Many2one('product.uom', 'Unit')
    rate1 = fields.Float('Unit Rate')
    rate2 = fields.Float('Unit Rate')
    rate3 = fields.Float('Unit Rate')
    sub_total1 = fields.Float('Value', compute="get_total")
    sub_total2 = fields.Float('Value', compute="get_total")
    sub_total3 = fields.Float('Value', compute="get_total")
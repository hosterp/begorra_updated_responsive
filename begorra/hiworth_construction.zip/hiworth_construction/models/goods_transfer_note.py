from openerp import fields, models, api,_
from datetime import date,datetime
from openerp.exceptions import except_orm,ValidationError

class GoodsTransferDummy(models.Model):

    _name = 'goods.transfer.dummy'



    @api.one
    def get_total(self):
        for s in self :
            s.value= s.rate * s.qty

    item_id = fields.Many2one('product.product', 'Item')
    desc = fields.Char('Description')
    specs = fields.Char('Specification')
    qty = fields.Float('Qty')
    rate = fields.Float('Rate')
    value = fields.Float('Value',compute='get_total')
    remarks = fields.Char('Remarks')
    transfer_list_id = fields.Many2one('goods.transfer.note.in')
    transfer_recieve_id = fields.Many2one('goods.recieve.report')
    
    

class GoodsTransferNoteIn(models.Model):
    _name = 'goods.transfer.note.in'
    _rec_name = 'gtn_no'

    
    @api.model
    def create(self, vals):
        res = super(GoodsTransferNoteIn,self).create(fields)
        vals.update({'user_id':self.env.user.id})
        if vals.get('gtn_no', '/') == '/':
            project = self.env['project.project'].browse(vals['project_id']).name
            vals.update({'gtn_no' :'GTN/' + str(project) + str(self.env['ir.sequence'].next_by_code('gtn.code'))})
        return res
    
             

    
            




    


    project_id = fields.Many2one('project.project', 'Project', required=True)
    site_from = fields.Many2one('stock.location', 'From')
    site_to = fields.Many2one('stock.location', 'To')
    gtn_no = fields.Char('GTN NO')
    date = fields.Date('Date')
    transfer_list_ids = fields.One2many('goods.transfer.dummy','transfer_list_id')
    user_created = fields.Many2one('res.users', 'Prepared by')
    project_manager = fields.Many2one('res.users', 'Project Manager')
    purchase_manager = fields.Many2one('res.users', 'Purchase Manager')
    dgm_id = fields.Many2one('res.users', 'GM')
    state = fields.Selection([('draft', 'Draft'),
                              ('confirm', 'Requested'),
                              ('approved1', 'Approved By PM'),
                              ('transfer', 'Transferred'),
                              ('recieve', 'Recieved'),
                              ('cancel', 'Cancelled')], default="draft", string="Status")
    goods_transfer_bool = fields.Boolean('Goods transfer',default="True" )
    user_id = fields.Many2one('res.users',string="Users")
    store_manager_id = fields.Many2one('res.users',"Store manager")
    transfer_gtn_id = fields.Many2one('goods.transfer.note.in',"Transfer ")

    @api.multi
    def set_draft(self):
        self.state = 'draft'
        self.request_not_in_draft = False
    @api.multi
    def confirm_purchase(self):
            self.user_created = self.env.user.id
            self.state = 'confirm'
            self.request_not_in_draft = True

    @api.multi
    def approve_purchase1(self):
        self.project_manager = self.env.user.id
        self.state = 'approved1'
    @api.multi
    def action_transfer(self):
        for rec in self:
            if rec.goods_transfer_bool == True:
                values={'user_id':rec.store_manager_id.id,
                        'store_manager_id':rec.user_id.id,
                        'project_id':rec.project_id.id,
                        'site_from':rec.site_from.id,
                        'site_to':rec.site_to.id,
                        'gtn_no':rec.gtn_no,
                        'date':rec.date,
                        'user_created':rec.user_created.id,
                        'project_manager':rec.project_manager.id,
                        'purchase_manager':rec.purchase_manager.id,
                        'dgm_id':rec.dgm_id.id,
                        'state':'transfer',
                        'goods_transfer_bool':False,
                        'transfer_gtn_id':rec.id
                        
                        
                        }
                value_list =[]
                for transfer in rec.transfer_list_ids:
                    value_list.append((0,0,{'item_id':transfer.item_id.id,
                                            'desc':transfer.desc,
                                            'specs':transfer.specs,
                                            'qty':transfer.qty,
                                            'rate':transfer.rate,
                                            'value':transfer.value,
                                            'remarks':transfer.remarks}))
                    
                values.update({'transfer_list_ids':value_list})
                self.env['goods.transfer.note.in'].create(values)
            else:
                values = {'user_id': rec.store_manager_id.id,
                          'store_manager_id': rec.user_id.id,
                          'project_id': rec.project_id.id,
                          'site_from': rec.site_from.id,
                          'site_to': rec.site_to.id,
                          'gtn_no': rec.gtn_no,
                          'date': rec.date,
                          'user_created': rec.user_created.id,
                          'project_manager': rec.project_manager.id,
                          'purchase_manager': rec.purchase_manager.id,
                          'dgm_id': rec.dgm_id.id,
                          'state': 'transfer',
                          'goods_transfer_bool': True,
                          'transfer_gtn_id': rec.id
        
                          }
                value_list = []
                for transfer in rec.transfer_list_ids:
                    value_list.append((0, 0, {'item_id': transfer.item_id.id,
                                              'desc': transfer.desc,
                                              'specs': transfer.specs,
                                              'qty': transfer.qty,
                                              'rate': transfer.rate,
                                              'value': transfer.value,
                                              'remarks': transfer.remarks}))
    
                values.update({'transfer_list_ids': value_list})
                self.env['goods.transfer.note.in'].create(values)
                
        
        
        self.state = 'transfer'
        self.purchase_manager = self.env.user.id
    @api.multi
    def approve_purchase3(self):
        for rec in self:
            stock_lines = []
            for req in rec.transfer_list_ids:
                stock_lines.append((0, 0, {
                    'location_id': rec.site_from.id,
            
                    'product_id': req.item_id.id,
                    'available_qty': req.item_id.with_context(
                        {'location': rec.site_to.id}).qty_available,
                    'name': req.desc,
                    'product_uom_qty': req.qty,
                    'product_uom': req.item_id.uom_id.id,
                    'price_unit': req.rate,
                    'account_id': rec.site_to.related_account.id,
                    'location_dest_id': rec.site_to.id,
                }))
            if stock_lines:
                journal_id = self.env['account.journal'].search([('type', '=', 'general'), ('code', '=', 'STJ')])
                stock = self.env['stock.picking'].create({
            
                    'source_location_id': rec.site_from.id,
            
                    'site': rec.site_to.id,
                    'order_date': rec.date,
                    'account_id': rec.site_to.related_account.id,
                    'supervisor_id': self.env.user.employee_id.id,
                    'move_lines': stock_lines,
                    'is_purchase': False,
                    'journal_id': journal_id.id,
            
                })
    
            stock.action_confirm()
            stock.sudo().action_assign()
            stock.sudo().state = 'assigned'
            stock.date_done = datetime.today()
            stock.sudo().do_enter_transfer_details()
            print "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
            created_id = self.env['stock.transfer_details'].create({
                'picking_id': len(stock) and stock[0].id or False})
            for req in rec.material_issue_slip_lines_ids:
                values = ({
                    'product_id': req.item_id.id,
                    'price_unit': 1,
                    'quantity': req.qty,
                    'product_uom_id': req.item_id.uom_id.id,
                    'sourceloc_id': rec.site_from.id,
                    'destinationloc_id': rec.site_to.id,
                    'transfer_id': created_id.id
                })
                transfer_details = self.env['stock.transfer_details_items'].create(values)
            created_id.sudo().do_detailed_transfer()
        
        
        self.state = 'recieve'
        self.dgm_id = self.env.user.id

    @api.multi
    def cancel_process(self):
        self.state = 'cancel'

    @api.multi
    def goods_transfer_report(self):

        transfer_list=[]
        for rec in self:
            for tlist in rec.transfer_list_ids:
                print 'ttttttttttttttttttttttt',tlist
                transfer_dict={
                            'item_id':tlist.item_id.name,
                            'desc':tlist.desc,
                            'specs':tlist.specs,
                            'qty':tlist.qty,
                            'rate':tlist.rate,
                            'value':tlist.value,
                            'remarks':tlist.remarks,

                            }
                transfer_list.append(transfer_dict)
                print 'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrr',transfer_list
        return transfer_list
        
class GoodsRecieveReport(models.Model):

    _name = "goods.recieve.report"
    _rec_name = 'grr_no'

    @api.model
    def create(self,vals):
        if vals.get('name', '/') == '/':
            project = self.env['project.project'].browse(vals['project_id']).name
            vals['grr_no'] = 'GRR/' + str(project) + str(self.env['ir.sequence'].next_by_code('grr.code'))
        
        order = super(GoodsRecieveReport, self).create(vals)
        print "wwwwwwwwwwwwwwwwwwwwwwwwww",order
        order.picking_create()
        
        return order
    
    @api.multi
    def picking_create(self):
        print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",self
        values = {}
        for goods_receive in self:
            stock_lines = []
            return_stock_lines = []
            for req in goods_receive.goods_recieve_report_line_ids:
                    stock_lines.append((0, 0, {
                        'location_id': goods_receive.supplier_location_id.id,
                        'project_id': goods_receive.project_id.id,
                        'product_id': req.item_id.id,
                        'available_qty': req.item_id.with_context({'location': goods_receive.project_location_id.id}).qty_available,
                        'name': req.desc,
                        'product_uom_qty': req.quantity_rec,
                        'product_uom': req.item_id.uom_id.id,
                        'price_unit':req.rate,
                        'account_id': goods_receive.project_location_id.related_account.id,
                        'location_dest_id': goods_receive.project_location_id.id,
                    }))
                   
               
            # print "stock lines=======================",stock_lines
            if stock_lines:
                stock = self.env['stock.picking'].create({
                    'request_id': self.mpr_id.id,
                    'source_location_id': goods_receive.supplier_location_id.id,
                    'partner_id': goods_receive.supplier_id.id,
                    'site': goods_receive.project_location_id.id,
                    'order_date': self.Date,
                    'account_id':goods_receive.supplier_id.property_account_payable.id,
                    'supervisor_id': self.env.user.employee_id.id,
                    'move_lines': stock_lines,
                    'is_purchase':True,
                    'project_id':goods_receive.project_id.id,
                })

                stock.action_confirm()
                stock.sudo().action_assign()
                stock.sudo().state = 'assigned'
                stock.date_done = datetime.today()
                stock.sudo().do_enter_transfer_details()
                print "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",stock.state
                created_id = self.env['stock.transfer_details'].create({
                    'picking_id': len(stock) and stock[0].id or False})
                for req in goods_receive.goods_recieve_report_line_ids:
                
                    values = ({
                        'product_id': req.item_id.id,
                        'price_unit': req.rate,
                        'quantity': req.quantity_rec,
                        'product_uom_id': req.item_id.uom_id.id,
                        'sourceloc_id': goods_receive.supplier_location_id.id,
                        'destinationloc_id': goods_receive.project_location_id.id,
                        'transfer_id':created_id.id
                            })
                    transfer_details = self.env['stock.transfer_details_items'].create(values)
                created_id.sudo().do_detailed_transfer()
                goods_receive.picking_id = stock.id
                
                
                for req in goods_receive.goods_recieve_report_line_ids:
                    if req.quantity_reject != 0.0:
                        move_id = self.env['stock.move'].create({
                            'location_id': goods_receive.supplier_location_id.id,
                            'project_id': goods_receive.project_id.id,
                            'product_id': req.item_id.id,
                            'available_qty': req.item_id.with_context(
                                {'location': goods_receive.project_location_id.id}).qty_available,
                            'name': req.desc,
                            'product_uom_qty': req.quantity_reject,
                            'product_uom': req.item_id.uom_id.id,
                            'price_unit': req.rate,
                            'account_id': goods_receive.project_location_id.related_account.id,
                            'location_dest_id': goods_receive.project_location_id.id,
                        })
                        move_id.action_done()
                        return_stock_lines.append((0, 0, {
                           
                            'product_id': req.item_id.id,
                          
                            'quantity': req.quantity_reject,
                            'move_id':move_id.id,
                           
                        }))

                returned_products = self.env['stock.return.picking'].create({'product_return_moves':return_stock_lines,
                                                                             'move_dest_exists':True,
                                                                             'invoice_state':'none'}).with_context({'active_id':[stock.id]})
                
                
                new_picking,old_picking = returned_products._create_returns()
                new_picking_id = self.env['stock.picking'].browse(new_picking)
                new_picking_id.sudo().state = 'assigned'
                new_picking_id.date_done = datetime.today()
                new_picking_id.sudo().do_enter_transfer_details()
                created_id = self.env['stock.transfer_details'].create({
                        'picking_id': len(new_picking_id) and new_picking_id[0].id or False})
                for req in goods_receive.goods_recieve_report_line_ids:
                    if req.quantity_reject!=0:
                        values = ({
                                     'product_id': req.item_id.id,
                                     'price_unit': req.rate,
                                    'quantity': req.quantity_reject,
                                    'product_uom_id': req.item_id.uom_id.id,
                                     'sourceloc_id': goods_receive.supplier_location_id.id,
                                     'destinationloc_id': goods_receive.project_location_id.id,
                                     'transfer_id': created_id.id
                                })
                    transfer_details = self.env['stock.transfer_details_items'].create(values)
                created_id.sudo().do_detailed_transfer()
                # stock.sudo().state = 'assigned'
                # stock.date_done = datetime.today()
                # stock.sudo().do_enter_transfer_details()
                # print
                # "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
                # created_id = self.env['stock.transfer_details'].create({
                #     'picking_id': len(stock) and stock[0].id or False})
                # for req in goods_receive.goods_recieve_report_line_ids:
                #     values = ({
                #         'product_id': req.item_id.id,
                #         'price_unit': req.rate,
                #         'quantity': req.quantity_rec,
                #         'product_uom_id': req.item_id.uom_id.id,
                #         'sourceloc_id': goods_receive.supplier_location_id.id,
                #         'destinationloc_id': goods_receive.project_location_id.id,
                #         'transfer_id': created_id.id
                #     })
                #     transfer_details = self.env['stock.transfer_details_items'].create(values)
                # created_id.sudo().do_detailed_transfer()
                
                
                
                
                

                

                
                
                

    project_id = fields.Many2one('project.project', 'Project', required=True)
    supplier_id = fields.Many2one('res.partner','Supplier',required=True)
    supplier_location_id = fields.Many2one('stock.location','Location',required=True)
    project_location_id = fields.Many2one('stock.location','Project Location',required=True)
    mpr_id = fields.Many2one('site.purchase',"MPR No")
    purchase_id = fields.Many2one('purchase.order','PO No',required=True)
    po_no = fields.Char('P.O.No')
    grr_no = fields.Char('GRR No')
    Date = fields.Date('Date')
    picking_id = fields.Many2one('stock.picking',"Picking")
    goods_recieve_report_line_ids = fields.One2many('goods.recieve.report.line','goods_recieve_report_id')
    
    
    @api.multi
    def action_return(self):
        if req.quantity_reject != 0.0:
            return_stock_lines.append((0, 0, {
                'location_id': goods_receive.project_location_id.id,
                'project_id': goods_receive.project_id.id,
                'product_id': req.item_id.id,
                'available_qty': req.item_id.with_context(
                    {'location': goods_receive.project_location_id.id}).qty_available,
                'name': req.desc,
                'product_uom_qty': req.quantity_reject,
                'product_uom': req.item_id.uom_id.id,
                'price_unit': req.rate,
                'account_id': goods_receive.supplier_id.property_account_payable.id,
                'location_dest_id': goods_receive.supplier_location_id.id,
            }))
        if return_stock_lines:
            stock = self.env['stock.picking'].create({
                'request_id': self.mpr_id.id,
                'source_location_id': goods_receive.project_location_id.id,
                'partner_id': goods_receive.supplier_id.id,
                'site': goods_receive.project_location_id.id,
                'order_date': self.Date,
                'account_id': goods_receive.supplier_id.property_account_payable.id,
                'supervisor_id': self.env.user.employee_id.id,
                'move_lines': stock_lines,
                'is_purchase': True,
                'project_id': goods_receive.project_id.id,
            })
        
            stock.action_confirm()
            stock.sudo().action_assign()
            stock.sudo().state = 'assigned'
            stock.date_done = datetime.today()
            stock.sudo().do_enter_transfer_details()
            print
            "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
            created_id = self.env['stock.transfer_details'].create({
                'picking_id': len(stock) and stock[0].id or False})
            for req in goods_receive.goods_recieve_report_line_ids:
                if req.quantity_reject != 0.0:
                    values = ({
                        'product_id': req.item_id.id,
                        'price_unit': req.rate,
                        'quantity': req.quantity_reject,
                        'product_uom_id': req.item_id.uom_id.id,
                        'sourceloc_id': goods_receive.project_location_id.id,
                        'destinationloc_id': goods_receive.supplier_location_id.id,
                        'transfer_id': created_id.id
                    })
                transfer_details = self.env['stock.transfer_details_items'].create(values)
            created_id.sudo().do_detailed_transfer()
    
    
    
class GoodsRecieveReportLine(models.Model):

    _name = "goods.recieve.report.line"
    
    
    @api.onchange('item_id')
    def onchange_item_id(self):
        for rec in self:
            if rec.item_id:
                rec.desc = rec.item_id.name
    

    item_id = fields.Many2one('product.product', 'Item')
    desc = fields.Char('Description')
    specs = fields.Char('Specification')
    quantity_rec = fields.Float('Quantity Received')
    quantity_accept = fields.Float('Quantity Accepted')
    quantity_reject = fields.Float('Quantity Rejected')
    rate = fields.Float('Price')
    remarks = fields.Char('Remarks')
    goods_recieve_report_id = fields.Many2one('goods.recieve.report',string="Goods Recieve Report")
    date = fields.Date(string="Date")
    
    
    
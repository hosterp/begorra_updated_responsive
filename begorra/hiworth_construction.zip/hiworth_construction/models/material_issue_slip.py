from openerp import fields, models, api
from datetime import datetime
from openerp.exceptions import Warning as UserError
from openerp.osv import osv
from openerp.tools.translate import _
from dateutil import relativedelta
from openerp.exceptions import except_orm, ValidationError


class MaterialIssueSlip(models.Model):
	_name = 'material.issue.slip'
	_order = 'date desc'




	name = fields.Char('Name')
	date = fields.Date('Date', default=datetime.today())
	project_id = fields.Many2one('project.project')
	source_location_id = fields.Many2one('stock.location',"Source Location")
	location_id = fields.Many2one('stock.location',"Location")
	material_issue_slip_lines_ids = fields.One2many('material.issue.slip.line','material_issue_slip_id',string="Item List")
	state = fields.Selection([('draft','Draft'),
							  ('request','Request'),
							  ('receive','Received')],default='draft',String="Status")
	user_id = fields.Many2one('res.users',"Users")
	store_manager_id = fields.Many2one('res.users',"Supervisor")
	is_debit_note = fields.Boolean("Is a Debit Note",default=False)
	
			
	@api.multi
	def action_receive(self):
		for rec in self:
			stock_lines = []
			for req in rec.material_issue_slip_lines_ids:
				stock_lines.append((0, 0, {
					'location_id': rec.source_location_id.id,
					'project_id': rec.project_id.id,
					'product_id': req.item_id.id,
					'available_qty': req.item_id.with_context(
						{'location': rec.location_id.id}).qty_available,
					'name': req.desc,
					'product_uom_qty': req.quantity,
					'product_uom': req.unit_id.id,
					'price_unit': 1,
					'account_id': rec.location_id.related_account.id,
					'location_dest_id': rec.location_id.id,
				}))
			if stock_lines:
				journal_id = self.env['account.journal'].search([('type','=','general'),('code','=','STJ')])
				stock = self.env['stock.picking'].create({
					
					'source_location_id': rec.source_location_id.id,
					
					'site': rec.location_id.id,
					'order_date': rec.date,
					'account_id': rec.location_id.related_account.id,
					'supervisor_id': self.env.user.employee_id.id,
					'move_lines': stock_lines,
					'is_purchase': False,
					'journal_id':journal_id.id,
					'project_id': rec.project_id.id,
				})
			
			stock.action_confirm()
			stock.sudo().action_assign()
			stock.sudo().state = 'assigned'
			stock.date_done = datetime.today()
			stock.sudo().do_enter_transfer_details()
			print "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
			created_id = self.env['stock.transfer_details'].create({
				'picking_id': len(stock) and stock[0].id or False})
			for req in rec.material_issue_slip_lines_ids:
				values = ({
					'product_id': req.item_id.id,
					'price_unit': 1,
					'quantity': req.quantity,
					'product_uom_id': req.unit_id.id,
					'sourceloc_id': rec.source_location_id.id,
					'destinationloc_id': rec.location_id.id,
					'transfer_id': created_id.id
				})
				transfer_details = self.env['stock.transfer_details_items'].create(values)
			created_id.sudo().do_detailed_transfer()
			
			rec.state = 'receive'
			
			
	@api.model
	def create(self,vals):
		
		if vals.get('name', '/') == '/':
			project = self.env['project.project'].browse(vals['project_id']).name
			vals.update({'name': 'MRN/' + str(project) + str(self.env['ir.sequence'].next_by_code('mrn.code'))})
		res =super(MaterialIssueSlip, self).create(vals)
		
		return res
	
	@api.multi
	def action_debit_note(self):
		for rec in self:
			if	rec.is_debit_note == True:
				values = {'partner_id':rec.store_manager_id.id,
						  'location_id':rec.location_id.id,
						  'source_location_id':rec.source_location_id.id,
						  'is_material_request':True,
						  'material_requst_id':rec.id,
						  }
				self.env['debit.note.supplier'].create(values)

class MaterialIssuelipLine(models.Model):
	_name = 'material.issue.slip.line'


	@api.onchange('item_id')
	def onchange_date(self):
		for rec in self:
			if rec.material_issue_slip_id.date:
				rec.date = rec.material_issue_slip_id.date
			if rec.item_id:
				rec.desc = rec.item_id.name
				
				
	@api.onchange('project_id')
	def onchange_product(self):
		for rec in self:
			if rec.material_issue_slip_id.project_id:
				rec.project_id = rec.material_issue_slip_id.project_id




	item_id = fields.Many2one('product.product',string="Product")
	quantity = fields.Float(string="Quantity")
	unit_id = fields.Many2one('product.uom')
	desc = fields.Char(string="Description")
	remarks = fields.Text(string="Remarks")
	material_issue_slip_id = fields.Many2one('material.issue.slip',string="Material Issue Slip")
	date = fields.Date('Date')
	project_id = fields.Many2one('project.project')

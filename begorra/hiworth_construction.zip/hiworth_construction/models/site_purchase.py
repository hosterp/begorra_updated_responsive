from openerp import models, fields, api, _
from openerp.exceptions import except_orm, ValidationError
from datetime import datetime
from datetime import datetime
from dateutil.relativedelta import relativedelta

class InventoryDepartment(models.Model):
	_name = 'inventory.department'

	name = fields.Many2one('product.product','Product')
	date = fields.Date('Date')
	location_id = fields.Many2one('stock.location','Location')
	qty = fields.Float('Quantity')
	rate = fields.Float('Rate')
	inventory_value = fields.Float('Inventory Value')
	department = fields.Selection([('general','General'),
								   ('vehicle','Vehicle'),
								   ('telecom','Telecom'),
								   ('interlocks','Interlocks'),
								   ('workshop','Workshop')],string="Department")
	site_purchase_id = fields.Many2one('site.purchase')





class SitePurchasegroup(models.Model):
	_name = 'site.purchase.group'

	@api.multi
	def merge_orders(self):
		site_requests = self.env.context.get('active_ids')
		record = []
		supplier = False
		for request in site_requests:
			site_record = self.env['site.purchase'].search([('id','=',request)])
			if site_record:
				if site_record.state != 'approved2':
					raise except_orm(_('Warning'),_('Site Requests Must Be In Draft State.Please Check..!!'))
				if not site_record.expected_supplier:
					raise except_orm(_('Warning'),_('One of the site requests not have supplier.Please configure..!!'))
				if supplier == False:
					supplier = site_record.expected_supplier.id
				elif supplier != site_record.expected_supplier.id:
					raise except_orm(_('Warning'),_('Supplers are different..!!'))

				line_record = {
					'product_id':site_record.item_id.id,
					'product_qty':site_record.quantity,
					'name':site_record.item_id.name,
					'site_purchase_id':site_record.id,
					'product_uom':site_record.unit.id,
					'pro_old_price':site_record.item_id.standard_price,
					'unit_price':site_record.item_id.standard_price,
					'price_unit':site_record.item_id.standard_price,
					'location_id':False,
					'account_id':site_record.item_id.categ_id.stock_account_id.id,
					'state':'draft'
					}
				record.append((0, False, line_record ))


		view_ref = self.env['ir.model.data'].get_object_reference('purchase', 'purchase_order_form')
		view_id = view_ref[1] if view_ref else False
		res = {
		   'type': 'ir.actions.act_window',
		   'name': _('Purchase Order'),
		   'res_model': 'purchase.order',
		   'view_type': 'form',
		   'view_mode': 'form',
		   'view_id': view_id,
		   'target': 'current',
		   'context': {'default_partner_id':supplier,'default_order_line':record,'default_date_order':fields.Date.today(),'default_state':'draft'}
	   }

		return res


class SitePurchase(models.Model):
	_name = 'site.purchase'
	_order = 'id desc'

	@api.onchange('quantity')
	def onchange_quantity_rate(self):
		if self.quantity == 0:
			self.estimated_amt = 0
		else:
			if self.estimated_amt != 0 and self.rate != 0 and self.quantity != round((self.estimated_amt / self.rate),
																					 2):
				self.quantity = 0.0
				return {
					'warning': {
						'title': 'Warning',
						'message': "For Entering value to quantity field, Rate or estimated_amt should be Zero"
					}
				}
			if self.quantity != 0 and self.rate != 0:
				if self.rate * self.quantity != self.estimated_amt:
					pass
				if self.estimated_amt == 0.0:
					self.estimated_amt = round((self.quantity * self.rate), 2)
			if self.estimated_amt != 0 and self.quantity != 0:
				if self.rate == 0.0:
					self.rate = round((self.estimated_amt / self.quantity), 2)

	@api.onchange('rate')
	def onchange_rate_estimated_amt(self):
		if self.rate == 0:
			self.estimated_amt = 0
		else:
			if self.estimated_amt != 0 and self.quantity != 0 and self.rate != round(
					(self.estimated_amt / self.quantity), 2):
				self.rate = 0.0
				return {
					'warning': {
						'title': 'Warning',
						'message': "For Entering value to Rate field, quantity or estimated_amt should be Zero."
					}
				}
			if self.quantity != 0 and self.rate != 0:
				if self.rate * self.quantity != self.estimated_amt:
					pass
				if self.estimated_amt == 0.0:
					self.estimated_amt = round((self.quantity * self.rate), 2)
			if self.estimated_amt != 0 and self.rate != 0:
				if self.quantity == 0.0:
					self.quantity = round((self.estimated_amt / self.rate), 2)

	@api.onchange('estimated_amt')
	def onchange_qty_estimated_amt(self):
		if self.estimated_amt != 0:
			if self.rate * self.quantity != self.estimated_amt:
				if self.rate != 0 and self.quantity != 0:
					self.estimated_amt = 0.0
					return {
						'warning': {
							'title': 'Warning',
							'message': "For Entering value to estimated_amt field, quantity or Rate should be Zero."
						}
					}
				elif self.rate == 0 and self.quantity != 0:
					self.rate = round((self.estimated_amt / self.quantity), 2)
				elif self.quantity == 0 and self.rate != 0:
					self.quantity = round((self.estimated_amt / self.rate), 2)
				else:
					pass

	@api.onchange('item_id')
	def onchange_product_id(self):

		if self.item_id:
			self.unit = self.item_id.uom_id.id
			self.desc = self.item_id.name

	@api.onchange('min_expected_date', 'max_expected_date')
	def onchange_min_expected_date1(self):
		current_date = datetime.now().date()
		if self.min_expected_date and (self.min_expected_date < str(current_date)):
			self.min_expected_date = False
		# raise except_orm(_('Warning'), ('Expected date should not be lesser than current date..'))

		if self.max_expected_date and (self.max_expected_date < str(current_date)):
			self.max_expected_date = False

	@api.model
	def default_get(self, default_fields):
		vals = super(SitePurchase, self).default_get(default_fields)
		user = self.env['res.users'].search([('id', '=', self.env.user.id)])
		if user:
			vals.update({'responsible': user.id})
			if user.employee_id or user.id == 1:
				vals.update({'supervisor_id': user.employee_id.id if user.id != 1 else self.env['hr.employee'].search(
					[('id', '=', 1)]).id})

		return vals

	@api.multi
	@api.depends('tax_ids', 'received_total')
	def get_tax_amount(self):
		for lines in self:
			# if lines.state == 'processing':
			# 	flag1 = 0
			# 	flag2 = 0
			# 	for p in self.env['purchase.order'].search([('request_id', '=', lines.id)]):
			# 		if p:
			# 			if p.state != 'done':
			# 				flag1 = 1
			# 	for s in self.env['stock.picking'].search([('request_id', '=', lines.id)]):
			# 		if s:
			# 			if s.state != 'done':
			# 				flag2 = 1
			# 	if flag1 == 0 and flag2 == 0:
			# 		lines.state = 'received'
			taxi = 0
			taxe = 0
			for tax in lines.tax_ids:
				if tax.price_include == True:
					taxi = tax.amount
				if tax.price_include == False:
					taxe += tax.amount
			lines.tax_amount = (lines.received_total) / (1 + taxi) * (taxi + taxe)
			lines.sub_total = (lines.received_total) / (1 + taxi)
			lines.total_amount = lines.tax_amount + lines.sub_total

	@api.multi
	@api.depends('received_qty', 'received_rate')
	def get_received_total(self):
		for rec in self:
			rec.received_total = rec.received_qty * rec.received_rate

	name = fields.Char('Name', readonly=True)
	supervisor_id = fields.Many2one('hr.employee', 'User')
	responsible = fields.Many2one('res.users', 'Responsible', readonly=True)
	order_date = fields.Datetime('Order Date', readonly=False, default=datetime.now().date())
	min_expected_date = fields.Date('Minimum Expected Date', required=True)
	max_expected_date = fields.Date('Maximum Expected Date')
	received_date = fields.Date('Received Date')
	item_id = fields.Many2one('product.product', 'Item')
	quantity = fields.Float('Quantity')
	unit = fields.Many2one('product.uom', 'Unit')
	req_list = fields.One2many('request.item.list', 'req_list_line', 'Req List')
	request_not_in_draft = fields.Boolean('flag')
	storekeeper_purchase = fields.Boolean('Store Keeper Purchase')
	state = fields.Selection([('draft', 'Draft'),
							  ('confirm', 'Requested'),
							  ('approved1', 'Approved By PM'),
							  ('approved2', 'Approved By GM'),
							  ('processing', 'Under Comparison'),
							  ('purchase', 'Under Purchase'),
							  ('received','Received'),
							  ('cancel', 'Cancelled')], default="draft", string="Status")
	site_id = fields.Many2one('partner.daily.statement')
	desc = fields.Char('Description')
	site = fields.Many2one('stock.location', 'Location')
	received_qty = fields.Float('Received Qty')
	received_rate = fields.Float('Received Rate')
	received_total = fields.Float(compute='get_received_total', string='Amount')
	general_purchase = fields.Boolean(default=False)
	vehicle_purchase = fields.Boolean(default=False)
	telecom_purchase = fields.Boolean(default=False)
	interlocks_purchase = fields.Boolean(default=False)
	workshop_purchase = fields.Boolean(default=False)
	bitumen_purchase = fields.Boolean(default=False)
	# expected_supplier = fields.Many2one('res.partner','Supplier')
	rate = fields.Float('Rate')
	estimated_amt = fields.Float('Estimated Amount')
	purchase_manager = fields.Many2one('res.users', 'Purchase Manager')
	sign_general_manager = fields.Binary('Sign')
	project_manager = fields.Many2one('res.users', 'Project Manager')
	dgm_id = fields.Many2one('res.users', 'GM')
	sign_purchase_manager = fields.Binary('Sign')
	invoice_no = fields.Char('Invoice No.')
	invoice_date = fields.Date('Invoice Date')
	stock_move_id = fields.Many2one('stock.move', 'Stock Move')
	account_move_id = fields.Many2one('account.move', 'Journal Entry')
	tax_ids = fields.Many2many('account.tax', string="Tax")
	tax_amount = fields.Float('Tax Amount', compute="get_tax_amount")
	sub_total = fields.Float('Sub Total', compute="get_tax_amount")
	total_amount = fields.Float('Total', compute="get_tax_amount")
	bitumen_agent = fields.Many2one('res.partner', 'Agent')
	vehicle_agent = fields.Many2one('res.partner', 'Vehicle Agent')
	bank_id = fields.Many2one('res.partner.bank', 'Bank')
	doc_no = fields.Char('Doc No.')
	project_id = fields.Many2one('project.project', 'Project', required=True)
	req_no = fields.Char('Req No')
	remarks = fields.Text(string="Remarks")
	user_category = fields.Selection([('admin', 'Super User'),
									  ('project_manager', 'Project Manager'),
									  ('supervisor', 'Supervisor(Civil)'),
									  ('DGM', 'DGM'),
									  ], string='User Category', required=True, default='supervisor')

	@api.onchange('project_id')
	def onchange_project_id(self):
		if self.project_id:
			self.site = self.project_id.location_id.id

	@api.multi
	def cancel_process(self):
		if self.state != 'received':
			self.state = 'cancel'
		else:
			inv_record = self.env['inventory.department'].search([('site_purchase_id', '=', self.id)])
			if inv_record:
				inv_record.unlink()

		move = self.stock_move_id
		if move:
			quants = self.env['stock.quant'].search([('reservation_id', '=', move.id)])
			for quant in move.quant_ids:
				quant.sudo().qty = 0.0
			move.sudo().state = 'draft'
			# move.product_id.product_tmpl_id.sudo().qty_available = move.product_id.product_tmpl_id.qty_available - move.product_uom_qty
			move.sudo().unlink()

		account_move = self.account_move_id
		if account_move:
			account_move.button_cancel()
			account_move.unlink()

		self.state = 'cancel'

	@api.multi
	def set_draft(self):
		self.state = 'draft'
		self.request_not_in_draft = False

	@api.multi
	def confirm_purchase(self):
		if len(self.req_list):
			for r in self.req_list:
				if r.requested_quantity < 1:
					raise except_orm(_('Warning'), ('Request qty is zero for the product ' + str(r.item_id.name)))
			self.state = 'confirm'
			# self.user_category = 'project_manager'
			self.request_not_in_draft = True
			# self.env['popup.notifications'].sudo().create({
			# 	'name': self.project_id.user_id.id,
			# 	'status': 'draft',
			# 	'message': "You have a material request to approve from" + ' ' + self.supervisor_id.name})
		else:
			raise except_orm(_('Warning'), ('The Request items must be filled..'))

	@api.multi
	def view_moves(self):

		res = {
			'type': 'ir.actions.act_window',
			'name': _('Site To Site Transfer'),
			'res_model': 'stock.picking',
			'view_type': 'form',
			'view_mode': 'tree,form',
			# 'view_id': view_id,
			'target': 'current',
			'domain': [('request_id','=',self.id)]
			# 'context': {'default_partner_id': supplier, 'default_order_line': record,
			# 			'default_date_order': fields.Date.today(), 'default_state': 'draft'}
		}

		return res

	@api.multi
	def view_purchases(self):

		res = {
			'type': 'ir.actions.act_window',
			'name': _('Site Purchases'),
			'res_model': 'purchase.order',
			'view_type': 'form',
			'view_mode': 'tree,form',
			# 'view_id': view_id,
			'target': 'current',
			'domain': [('request_id', '=', self.id)]
			# 'context': {'default_partner_id': supplier, 'default_order_line': record,
			# 			'default_date_order': fields.Date.today(), 'default_state': 'draft'}
		}

		return res

	@api.multi
	def generate_po_stock(self):
		purchase_supplier = []
		stock_supplier = []
		self.purchase_manager = self.env.user.id
		comapany_location = self.env['stock.location'].search([('name', '=', 'Stock')])

		for line in self.req_list:
			if not line.expected_supplier and not line.stock_type == 'company_stock':
				raise except_orm(_('Operation not allowed!'),
								 _("No supplier Selected for product " + str(line.item_id.name)))
			if not line.stock_type:
				raise except_orm(_('Operation not allowed!'),
								 _("You should consider giving a stock type for product " + str(line.item_id.name)))
			if line.stock_type == 'supplier_stock' and line.expected_supplier not in purchase_supplier:
				purchase_supplier.append(line.expected_supplier)
			else:
				if line.expected_supplier not in stock_supplier:
					stock_supplier.append(line.expected_supplier)
		for s in purchase_supplier:
			purchase_lines = []
			for req in self.req_list:
				if req.expected_supplier.id == s.id and req.stock_type == 'supplier_stock':
					purchase_lines.append((0, 0, {
						'product_id': req.item_id.id,
						'name': req.desc,
						'required_qty': req.quantity,
						'product_uom': req.unit.id,
						'expected_rate': req.rate,
						'price_unit': 0.0,
						'account_id': self.env['account.account'].search([('name', '=', 'Purchase')]).id,
						'date_planned': self.min_expected_date,
						'site_purchase_id': self.id,
					}))
			order = self.env['purchase.order'].create({
				'partner_id': s.id,
				'request_id': self.id,
				'supervisor_id': self.supervisor_id.id,
				'project_id': self.project_id.id,
				'location_id': self.site.id,
				'account_id': s.property_account_payable.id,
				'minimum_planned_date': self.min_expected_date,
				'maximum_planned_date': self.max_expected_date,
				'request_date': self.order_date,
				'order_date': '',
				'pricelist_id': s.property_product_pricelist_purchase.id,
				'order_line': purchase_lines,
			})
		for s in stock_supplier:
			stock_lines = []
			for req in self.req_list:
				if req.expected_supplier.id == s.id and req.stock_type == 'company_stock':
					stock_lines.append((0, 0, {
						'location_id': req.location_id.id,
						'project_id': self.project_id.id,
						'product_id': req.item_id.id,
						'available_qty': req.item_id.with_context({'location': req.location_id.id}).qty_available,
						'name': req.desc,
						'product_uom_qty': req.quantity,
						'product_uom': req.unit.id,
						'account_id': self.site.related_account.id,
						'location_dest_id': self.site.id,
					}))
			# print "stock lines=======================",stock_lines
			if stock_lines:
				stock = self.env['stock.picking'].create({
					'request_id': self.id,
					'partner_id': s.id,
					'site': self.site.id,
					'order_date': self.order_date,
					'account_id': s.property_account_payable.id,
					'supervisor_id': self.supervisor_id.id,
					'move_lines': stock_lines
				})
		self.state = 'processing'

	@api.multi
	def approve_purchase1(self):
		self.project_manager = self.env.user.id
		self.state = 'approved1'
		# self.user_category = 'DGM'
		self.env['popup.notifications'].sudo().create({
			'name': self.project_id.user_id.id,
			'status': 'draft',
			'message': "You have a material request to approve from" + ' ' + self.supervisor_id.name
		})

	@api.multi
	def approve_purchase2(self):
		self.state = 'approved2'
		self.dgm_id = self.env.user.id
		# self.user_category = 'admin'
		# self.env['popup.notifications'].sudo().create({
		# 	'name': self.supervisor_id.id,
		# 	'status': 'draft',
		# 	'message': "You have a material request to approve" + ' ' + self.supervisor_id.name
		# })
	# 
	# @api.multi
	# def approve_purchase3(self):
	# 	self.state = 'approved3'
	# 	# self.user_category = False
	# 	self.env['popup.notifications'].sudo().create({
	# 		'name': self.project_id.pus_manager.id,
	# 		'status': 'draft',
	# 		'message': "You have a material request from" + ' ' + self.supervisor_id.name
	# 	})

	@api.multi
	def view_invoices(self):
		record = self.env['hiworth.invoice'].search([('site_purchase_id', '=', self.id)])

		if record:
			res_id = record[0].id
		else:
			res_id = False
		res = {
			'name': 'Supplier Invoices',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'hiworth.invoice',
			'domain': [('line_id', '=', self.id)],
			'res_id': res_id,
			'target': 'current',
			'type': 'ir.actions.act_window',
			'view_id': self.env.ref('hiworth_construction.hiworth_invoice_form').id,
			'context': {'default_inv_type': 'out', 'type2': 'out'},

		}

		return res

	@api.model
	def create(self, vals):

		if vals.get('supervisor_id') == False:
			user = self.env['res.users'].sudo().search([('id', '=', self.env.user.id)])
			if user:
				if user.employee_id or user.id == 1:
					vals['supervisor_id'] = user.employee_id.id if user.id != 1 else self.env['hr.employee'].search(
						[('id', '=', 1)]).id
				else:
					raise except_orm(_('Warning'), _('User have To Be Linked With Employee.'))

		if vals.get('site') == False:
			if vals.get('site_id'):
				vals['site'] = self.env['partner.daily.statement'].search(
					[('id', '=', vals['site_id'])]).location_ids.id

		result = super(SitePurchase, self).create(vals)
		if result.name == False:
			if result.general_purchase == True:
				result.name = str('MPR-') + self.env['ir.sequence'].next_by_code('site.purchase') or '/'
			
			result.order_date = fields.Datetime.now()
			for rec in result.req_list:
				if rec.requested_quantity == 0:
					raise except_orm(_('Warning'), _('Requested quantity must be greater than zero'))
		return result

class Request_Item_list(models.Model):
	_name = 'request.item.list'

	@api.onchange('requested_quantity')
	def onchange_requested_quantity(self):
		if self.requested_quantity:
			self.quantity = self.requested_quantity


	req_list_line = fields.Many2one('site.purchase')
	item_id = fields.Many2one('product.product','Item')
	available_quantity = fields.Float('Available Quantity')
	requested_quantity = fields.Float('Required Quantity')
	quantity = fields.Float('Approved Quantity')
	remarks = fields.Text('Remarks')
	unit = fields.Many2one('product.uom','Unit')
	rate = fields.Float('Rate')
	expected_supplier = fields.Many2one('res.partner', 'Supplier',domain=[('supplier','=',True)])
	location_id = fields.Many2one('stock.location', 'From')
	stock_type = fields.Selection([('company_stock', 'Company Stock'), ('supplier_stock', 'Supplier Stock')])
	estimated_amt = fields.Float('Estimated Amount', compute="get_estimate_amt")
	desc = fields.Char('Description')
	request_not_in_draft = fields.Boolean('flag', related="req_list_line.request_not_in_draft")

	@api.one
	def get_estimate_amt(self):
		for s in self:
			s.estimated_amt = s.quantity * s.rate

	# @api.onchange('stock_type')
	# def onchange_stock_type(self):
	# 	if self.stock_type == 'company_stock':
	# 		self.expected_supplier = 82

	@api.onchange('item_id')
	def onchange_product_id(self):

		if self.item_id:
			self.unit = self.item_id.uom_id.id
			self.desc = self.item_id.name
			self.available_quantity = self.item_id.with_context ({'location': self.req_list_line.site.id}).qty_available


class BcplAccountDetails(models.Model):
	_name = 'bcpl.account.details'


	item = fields.Char('Item')
	invoice_no = fields.Integer('Invoice No')
	doc = fields.Integer('Doc')
	order_date = fields.Date('Order Date')
	supplier = fields.Many2one('res.partner','Supplier')
	site_name = fields.Char('Site Name')
	qty = fields.Integer('Qty')
	rate = fields.Float('Rate')
	amount = fields.Float('Amount',compute= 'onchange_amount')
	agent = fields.Char('Agent')
	vehicle_no = fields.Char('Vehicle No')
	date = fields.Date('Date')
	bank = fields.Char('Bank')
	total_amount = fields.Float('Toatal Amount')


	@api.onchange('qty','rate')
	def onchange_amount(self):
		self.amount = self.qty*self.rate

class SitePurchaseReport(models.TransientModel):

	_name = 'site.purchase.report'

	requested_site_id = fields.Many2one('stock.location', 'Requested Site')
	date_from = fields.Date('Date From')
	date_to = fields.Date('Date To')
	project_id = fields.Many2one('project.project', 'Project')
	report_type = fields.Selection([('transfer', 'Goods Transfer Report'), ('receive', 'Goods Receive Report')])

	@api.multi
	def print_report(self):
		datas = {
			'model': 'hr.contribution.register',
			'form': self.read()[0],
		}
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'hiworth_construction.report_site_purchase_template',
			'datas': datas,
			'report_type': 'qweb-pdf'
		}

	@api.multi
	def print_report_html(self):
		datas = {
			'model': 'hr.contribution.register',
			'form': self.read()[0],
		}
		return {
			'type': 'ir.actions.report.xml',
			'report_name': 'hiworth_construction.report_site_purchase_template',
			'datas': datas,
			'report_type': 'qweb-html'
		}

class ReportSitePurchasTemplate(models.AbstractModel):

	_name = 'report.hiworth_construction.report_site_purchase_template'

	@api.model
	def render_html(self, docids, data=None):
		this = self.env['site.purchase.report'].browse(docids)
		if this:
			datas = []
			site = []
			domain = []
			if this.date_from:
				domain.append(('order_date', '>=', str(this.date_from) + " 00:01:01"))
			if this.date_to:
				domain.append(('order_date', '<=', str(this.date_to) + " 23:59:59"))
			if this.requested_site_id.id:
				domain.append(('site', '=', this.requested_site_id.id))
			if this.project_id.id:
				domain.append(('project_id', '=', this.project_id.id))
			if this.report_type == 'receive':
				domain.append(('state', '=', 'received'))
			for sp in self.env['site.purchase'].search(domain):
				if sp.site.id in site:
					for d in datas:
						if d['site_id'] == sp.site.id:
							for i in sp.req_list:
								if this.report_type == 'receive':
									if i.stock_type == 'supplier_stock':
										order_line = self.env['purchase.order.line'].search([('site_purchase_id', '=', sp.id), ('product_id', '=', i.item_id.id)])
										d['lines'].append({
											'location_id': i.location_id.name,
											'unit': i.unit.name,
											'supplier': i.expected_supplier.name or '',
											'po': order_line.order_id.name or '',
											'item_id': i.item_id.name,
											'default_code': i.item_id.default_code,
											'accepted_quantity': order_line.product_qty,
											'received_quantity': order_line.required_qty,
											'rejected_qty': order_line.required_qty - order_line.product_qty,
											'rate': i.rate,
											'estimated_amount': i.estimated_amt,
											'remarks': i.remarks,
										})
								if this.report_type == 'transfer':
									if i.stock_type == 'company_stock':
										d['lines'].append({
											'location_id': i.location_id.name or '',
											'unit': i.unit.name or '',
											'item_id': i.item_id.name or '',
											'default_code': i.item_id.default_code or '',
											'requested_quantity': i.requested_quantity or '',
											'quantity': i.quantity or '',
											'rate': i.rate or '',
											'estimated_amount': i.estimated_amt or '',
											'remarks': i.remarks or '',
										})
				else:
					s = {
						'site': sp.site.name,
						'site_id': sp.site.id,
						'lines': [],
						'grr': sp.name,
						'project': sp.project_id.name,
						'approved_by1': sp.purchase_manager.name or '',
						'approved_by2': sp.dgm_id.name or '',
						'approved_by3': sp.project_manager.name or ''
					}
					for i in sp.req_list:
						if this.report_type == 'receive':
							if i.stock_type == 'supplier_stock':
								order_line = self.env['purchase.order.line'].search(
									[('site_purchase_id', '=', sp.id), ('product_id', '=', i.item_id.id)])
								s['lines'].append({
									'location_id': i.location_id.name,
									'unit': i.unit.name,
									'supplier': i.expected_supplier.name or '',
									'po': order_line.order_id.name or '',
									'item_id': i.item_id.name,
									'default_code': i.item_id.default_code,
									'accepted_quantity': order_line.product_qty,
									'received_quantity': order_line.required_qty,
									'rejected_qty': order_line.required_qty - order_line.product_qty,
									'rate': i.rate,
									'estimated_amount': i.estimated_amt,
									'remarks': i.remarks,
								})
						if this.report_type == 'transfer':
							if i.stock_type == 'company_stock':
								s['lines'].append({
									'location_id': i.location_id.name or '',
									'unit': i.unit.name or '',
									'item_id': i.item_id.name or '',
									'default_code': i.item_id.default_code or '',
									'requested_quantity': i.requested_quantity or '',
									'quantity': i.quantity or '',
									'rate': i.rate or '',
									'estimated_amount': i.estimated_amt or '',
									'remarks': i.remarks or '',
								})
					if s['lines']:
						datas.append(s)
						site.append(sp.site.id)
			record = {
				'type': this.report_type,
				'data': datas
			}
			docargs = {
				'doc_ids': this.id,
				'doc_model': 'site.purchase',
				'docs': record,
			}

        	return self.env['report'].render('hiworth_construction.report_site_purchase_template', docargs)
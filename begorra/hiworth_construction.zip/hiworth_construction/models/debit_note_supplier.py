from openerp import fields, models, api
from datetime import datetime
from openerp.exceptions import Warning as UserError
from openerp.osv import osv
from openerp.tools.translate import _
from dateutil import relativedelta
from openerp.exceptions import except_orm, ValidationError


class DebitNoteSupplier(models.Model):
	_name = 'debit.note.supplier'
	_order = 'date desc'
	
	
	@api.model
	def create(self, vals):
		res = super(DebitNoteSupplier, self).create(vals)
		if vals.get('name', '/') == '/':
			project = ""
			vals.update({'name': 'DBN/' + str(project) + str(self.env['ir.sequence'].next_by_code('dbn.code'))})
	
		return res
	
	
	name = fields.Char('Name')
	date = fields.Date('Date', default=datetime.today())
	partner_id = fields.Many2one('res.users', 'User')
	source_location_id = fields.Many2one('stock.location',"Source Location")
	location_id = fields.Many2one('stock.location', "Location")
	debit_note_supplier_lines_ids = fields.One2many('debit.note.supplier.line', 'debit_note_supplier_id',
													string="Item List")
	state = fields.Selection([('draft', 'Draft'),
							  ('request', 'Request'),
							  ('receive', 'Received')], default='draft', String="Status")
	is_material_request = fields.Boolean('Material Request',default=False)
	material_requst_id = fields.Many2one('material.issue.slip',"Material Request")
	
	@api.multi
	def action_request(self):
		for rec in self:
			if rec.is_material_request != True:
				stock_lines = []
				for req in rec.debit_note_supplier_lines_ids:
					stock_lines.append((0, 0, {
						'location_id': rec.source_location_id.id,
						
						'product_id': req.item_id.id,
						'available_qty': req.item_id.with_context(
							{'location': rec.location_id.id}).qty_available,
						'name': req.desc,
						'product_uom_qty': req.quantity,
						'product_uom': req.unit_id.id,
						'price_unit': req.rate,
						'account_id': rec.location_id.related_account.id,
						'location_dest_id': rec.location_id.id,
					}))
				if stock_lines:
					journal_id = self.env['account.journal'].search([('type', '=', 'general'), ('code', '=', 'STJ')])
					stock = self.env['stock.picking'].create({
						
						'source_location_id': rec.source_location_id.id,
						
						'site': rec.location_id.id,
						'order_date': rec.date,
						'account_id': rec.location_id.related_account.id,
						'supervisor_id': self.env.user.employee_id.id,
						'move_lines': stock_lines,
						'is_purchase': False,
						'journal_id': journal_id.id,
						
					})
				
				stock.action_confirm()
				stock.sudo().action_assign()
				stock.sudo().state = 'assigned'
				stock.date_done = datetime.today()
				stock.sudo().do_enter_transfer_details()
				print "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
				created_id = self.env['stock.transfer_details'].create({
					'picking_id': len(stock) and stock[0].id or False})
				for req in rec.debit_note_supplier_lines_ids:
					values = ({
						'product_id': req.item_id.id,
						'price_unit': 1,
						'quantity': req.quantity,
						'product_uom_id': req.unit_id.id,
						'sourceloc_id': rec.source_location_id.id,
						'destinationloc_id': rec.location_id.id,
						'transfer_id': created_id.id
					})
					transfer_details = self.env['stock.transfer_details_items'].create(values)
				created_id.sudo().do_detailed_transfer()
				rec.state = 'request'
	
	@api.multi
	def action_receive(self):
		for rec in self:
			stock_lines = []
			for req in rec.debit_note_supplier_lines_ids:
				stock_lines.append((0, 0, {
					'location_id': rec.location_id.id,
					
					'product_id': req.item_id.id,
					'available_qty': req.item_id.with_context(
						{'location': rec.location_id.id}).qty_available,
					'name': req.desc,
					'product_uom_qty': req.quantity,
					'product_uom': req.unit_id.id,
					'price_unit': req.rate,
					'account_id': rec.location_id.related_account.id,
					'location_dest_id': rec.source_location_id.id,
				}))
			if stock_lines:
				journal_id = self.env['account.journal'].search([('type', '=', 'general'), ('code', '=', 'STJ')])
				stock = self.env['stock.picking'].create({
					
					'source_location_id': rec.location_id.id,
					
					'site': rec.location_id.id,
					'order_date': rec.date,
					'account_id': rec.location_id.related_account.id,
					'supervisor_id': self.env.user.employee_id.id,
					'move_lines': stock_lines,
					'is_purchase': False,
					'journal_id': journal_id.id,
					
				})
			
			stock.action_confirm()
			stock.sudo().action_assign()
			stock.sudo().state = 'assigned'
			stock.date_done = datetime.today()
			stock.sudo().do_enter_transfer_details()
			print "ststeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", stock.state
			created_id = self.env['stock.transfer_details'].create({
				'picking_id': len(stock) and stock[0].id or False})
			for req in rec.debit_note_supplier_lines_ids:
				values = ({
					'product_id': req.item_id.id,
					'price_unit': 1,
					'quantity': req.quantity,
					'product_uom_id': req.unit_id.id,
					'sourceloc_id': rec.location_id.id,
					'destinationloc_id': rec.source_location_id.id,
					'transfer_id': created_id.id
				})
				transfer_details = self.env['stock.transfer_details_items'].create(values)
			created_id.sudo().do_detailed_transfer()
			rec.state = 'receive'


class DebitNoteSupplierLine(models.Model):
	_name = 'debit.note.supplier.line'
	
	@api.depends('quantity','rate')
	def compute_amount(self):
		for rec in self:
			rec.total = rec.rate * rec.quantity
			
			
	item_id = fields.Many2one('product.product', string="Product")
	quantity = fields.Float(string="Quantity")
	unit_id = fields.Many2one('product.uom')
	desc = fields.Char(string="Description")
	rate = fields.Float(string="Rate")
	total = fields.Float(string="Total",compute='compute_amount')
	debit_note_supplier_id = fields.Many2one('debit.note.supplier', string="Material Issue Slip")
